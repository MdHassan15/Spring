package com.nagarro.training.csv_assignment_example.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.nagarro.training.csv_assignment_example.domain.TShirt;
import com.nagarro.training.csv_assignment_example.view.Output;

public class TShirtMatchingService {
	ArrayList<TShirt> list = new ArrayList<TShirt>();
	ArrayList<String> arr;
	Output out = new Output();

	public void searchData(String filename, String color, String size, String Gender_Recommendation)
			throws FileNotFoundException {
		Scanner sc = new Scanner(new File(filename));
		while (sc.hasNext()) {
			String line = sc.nextLine().toUpperCase().toString();
			if (!line.isEmpty()) {
				StringTokenizer token = new StringTokenizer(line, "|");
				arr = new ArrayList<String>(line.length());
				while (token.hasMoreTokens()) {
					arr.add(token.nextToken());
				}
				if (arr.get(2).equals(color) && arr.get(4).equals(size) && arr.get(3).equals(Gender_Recommendation)) {
					TShirt tshirt = new TShirt(arr.get(0), arr.get(1), arr.get(2), arr.get(3), arr.get(4),
							Float.parseFloat(arr.get(5)), Float.parseFloat(arr.get(6)), arr.get(7));
					list.add(tshirt);
				}
			}
		}
	}

	/*
	 * Sorting on basis of Price and Rating
	 */
	public void Sort(int ch) {
		if (ch == 1) {
			Collections.sort(list, new Comparator<TShirt>() {
				public int compare(TShirt o1, TShirt o2) {
					return ((int) (o1.getPrice()));
				}
			});
		} else if (ch == 2) {
			Collections.sort(list, new Comparator<TShirt>() {
				public int compare(TShirt o1, TShirt o2) {
					return ((int) (o2.getRating()));
				}
			});
		} else {
			System.out.println("Wrong Choice.");
			return;
		}
		Output.viewTShirt(list);

	}
}