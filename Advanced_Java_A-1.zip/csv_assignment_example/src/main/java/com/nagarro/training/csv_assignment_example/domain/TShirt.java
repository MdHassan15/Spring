package com.nagarro.training.csv_assignment_example.domain;

public class TShirt {

	private String ID;
	private String Name;
	private String Colour;
	private String Gender_Recommendation;
	private String Size;
	private double Price;
	private float Rating;
	private String Availability;

	public TShirt() {
	}

	public TShirt(String ID, String Name, String Colour, String Gender_Recommendation, String Size, float Price,
			float Rating, String Availability) {
		this.ID = ID;
		this.Name = Name;
		this.Colour = Colour;
		this.Gender_Recommendation = Gender_Recommendation;
		this.Size = Size;
		this.Price = Price;
		this.Rating = Rating;
		this.Availability = Availability;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		this.ID = ID;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = Name;
	}

	public String getColour() {
		return Colour;
	}

	public void setColour(String colour) {
		this.Colour = Colour;
	}

	public String getGender_Recommendation() {
		return Gender_Recommendation;
	}

	public void setGender_Recommendation(String gender_Recommendation) {
		this.Gender_Recommendation = Gender_Recommendation;
	}

	public String getSize() {
		return Size;
	}

	public void setSize(String size) {
		this.Size = Size;
	}

	public double getPrice() {
		return Price;
	}

	public void setPrice(double price) {
		this.Price = Price;
	}

	public float getRating() {
		return Rating;
	}

	public void setRating(float rating) {
		this.Rating = Rating;
	}

	public String getAvailability() {
		return Availability;
	}

	public void setAvailability(String availability) {
		this.Availability = Availability;
	}

}
