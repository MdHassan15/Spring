package com.nagarro.training.csv_assignment_example.view;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import com.nagarro.training.csv_assignment_example.service.TShirtMatchingService;

public class Input {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		String color, size, Gender_Recommendation;
		int ch;
		System.out.println("Enter the color:");
		color = sc.nextLine().toUpperCase();
		System.out.print("Enter Size : ");
		size = sc.nextLine().toUpperCase();
		System.out.print("Enter Gender_Recommendation:(M/F/U) : ");
		Gender_Recommendation = sc.nextLine().toUpperCase();
		System.out.print(
				"Enter Output Preference :   1. Sorted by Price \t 2. Sorted by Rating \n Enter Preference Choice : ");
		ch = sc.nextInt();

		TShirtMatchingService d = new TShirtMatchingService();

		d.searchData("resources\\Adidas.csv", color, size, Gender_Recommendation);
		d.searchData("resources\\Nike.csv", color, size, Gender_Recommendation);
		d.searchData("resources\\Puma.csv", color, size, Gender_Recommendation);
		d.Sort(ch);
	}

}
