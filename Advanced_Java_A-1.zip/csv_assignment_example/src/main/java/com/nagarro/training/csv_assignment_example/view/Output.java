package com.nagarro.training.csv_assignment_example.view;

import java.util.ArrayList;

import com.nagarro.training.csv_assignment_example.domain.TShirt;

public class Output {

	public static void viewTShirt(ArrayList<TShirt> list) {
		System.out.println("\n \t\t * T-SHIRT INFORMATION *");
		System.out.println("ID|NAME|COLOUR|GENDER_RECOMMENDATION|SIZE|PRICE|RATING|AVAILABILITY|");
		for (TShirt f : list) {
			System.out.print(f.getID());
			System.out.print("|" + f.getName());
			System.out.print("|" + f.getColour());
			System.out.print("|" + f.getGender_Recommendation());
			System.out.print("|" + f.getSize());
			System.out.print("|" + f.getPrice());
			System.out.print("|" + f.getRating());
			System.out.println("|" + f.getAvailability() + "|");
		}
		if (list.isEmpty()) {
			System.out.println("T-Shirt Not Available.");
		}
	}

}
